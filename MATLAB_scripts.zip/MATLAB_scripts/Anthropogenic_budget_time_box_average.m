%% Calculate change in the global budget
close all;clear all;clc;
%% load grid formation
x = rdmds('XC');
y = rdmds('YC');
z = rdmds('RC');
dx = rdmds('DXG');
dy = rdmds('DYG');
dz = rdmds('DRF');
da = rdmds('RAC');
hc = rdmds('hFacC');
dz3d = repmat(dz,[128 64 1]).*hc;
dv = repmat(da,[1 1 23]).*repmat(dz,[128 64 1]).*hc;
%% wrap around the globe
x(end+1,:)= x(end,:)+1;
y(end+1,:)= y(1,:);
%% load PI_results
% tracers
tracers_PI = rdmds('PI/PTRD1', 5040000);
mask = ones(128, 64);
mask(tracers_PI(:,:,1,1)==0)=NaN;
PO4_PI = tracers_PI(:,:,:,1);
NO3_PI = tracers_PI(:,:,:,2);
Fe_PI = tracers_PI(:,:,:,3);
SiO2_PI = tracers_PI(:,:,:,4);
% Phytoplankton
tracers2_PI = rdmds('PI/PTRD3',5040000);
Phy01_PI = tracers2_PI(:,:,:,2);
Phy02_PI = tracers2_PI(:,:,:,3);
Phy03_PI = tracers2_PI(:,:,:,4);
Phy04_PI = tracers2_PI(:,:,:,5);
Phy05_PI = tracers2_PI(:,:,:,6);
Phy06_PI = tracers2_PI(:,:,:,7);

Phy01_PI2d = sum(Phy01_PI.*dz3d,3);
Phy05_PI2d = sum(Phy05_PI.*dz3d,3);
Phy06_PI2d = sum(Phy06_PI.*dz3d,3);
Phy03_PI2d = sum(Phy03_PI.*dz3d,3);
Phy04_PI2d = sum(Phy04_PI.*dz3d,3);
% Production
Prod_PI = rdmds('PI/Production',5040000);
PP_PI2d = sum(Prod_PI.*dz3d,3);

% CO2flux
CO2_PI = rdmds('PI/CO2flux',5040000);

%% load Industrial Results timeseries
% tracers
time = [5040720:720:5112000];
for i =1:100
tracers_time(:,:,:,:,i) = rdmds('100yr/PTRD1', time(i));
PO4_time(:,:,:,i) = tracers_time(:,:,:,1,i);
NO3_time(:,:,:,i) = tracers_time(:,:,:,2,i);
Fe_time(:,:,:,i) = tracers_time(:,:,:,3,i);
SiO2_time(:,:,:,i) = tracers_time(:,:,:,4,i);

PO4_time_ano(:,:,:,i) = PO4_time(:,:,:,i) - PO4_PI;
NO3_time_ano(:,:,:,i)  = NO3_time(:,:,:,i) - NO3_PI;
Fe_time_ano(:,:,:,i) = Fe_time(:,:,:,i)- Fe_PI;
SiO2_time_ano(:,:,:,i) = SiO2_time(:,:,:,i) - SiO2_PI;
clear tracers_time
% Phytoplankton
tracers2_time(:,:,:,:,i) = rdmds('100yr/PTRD3',time(i));
Phy01_time(:,:,:,i) = tracers2_time(:,:,:,2,i);
Phy06_time(:,:,:,i) = tracers2_time(:,:,:,7,i);
Phy01_time_ano(:,:,:,i) = Phy01_time(:,:,:,i) - Phy01_PI;
Phy06_time_ano(:,:,:,i) = Phy06_time(:,:,:,i) - Phy06_PI;
Phy01_time_ano_2d(:,:,i) = sum(Phy01_time_ano(:,:,:,i).*dz3d,3);
Phy06_time_ano_2d(:,:,i) = sum(Phy06_time_ano(:,:,:,i).*dz3d,3);
clear tracers2_time
% Production
Prod_time(:,:,:,i) = rdmds('100yr/Production',time(i));
Prod_time_ano(:,:,:,i) = Prod_time(:,:,:,i) - Prod_PI;
Prod_time_ano_2d(:,:,i) = sum(Prod_time_ano(:,:,:,i).*dz3d,3);
% CO2flux
CO2_time(:,:,i) = rdmds('100yr/CO2flux',time(i));
CO2_time_ano(:,:,i) = CO2_time(:,:,i) - CO2_PI;
end

%% define box boundary
% Southern Ocean(south of 40�S): 1 40, Tropical Pacific (10�S-10�N): 70 90 150 250,
% North Pacific (120 140 150 240 , Indian Ocean (north of 40�S (60 100 50 100), and
% Tropical/North Atlantic (0N-60�N) 80 140 300 350 (based on papers)
% 33:39,25:29
Ix = [33:39];
Iy = [25:29];  
Iz = [1:10]; % the whole column 
vol = sum(sum(sum(dv)));
regvol = sum(sum(sum(dv(Ix(1):Ix(2),Iy(1):Iy(2),:))));

for i =1:100
regPO4(i) = sum(sum(sum(dv(33:39,25:29,1:10).*PO4_time_ano(33:39,25:29,1:10,i))));
regNO3(i) = sum(sum(sum(dv(33:39,25:29,1:10).*NO3_time_ano(33:39,25:29,1:10,i))));
regFe(i) = sum(sum(sum(dv(33:39,25:29,1:10).*Fe_time_ano(33:39,25:29,1:10,i))));
regSiO2(i) = sum(sum(sum(dv(33:39,25:29,1:10).*SiO2_time_ano(33:39,25:29,1:10,i))));
end

for i =1:100
regdiatom(i) = sum(sum(sum(dv(33:39,25:29,:).*Phy01_time_ano(33:39,25:29,:,i))));
regcocco(i) = sum(sum(sum(dv(33:39,25:29,:).*Phy06_time_ano(33:39,25:29,:,i))));
regNPP(i) = sum(sum(sum(dv(33:39,25:29,:).*Prod_time_ano(33:39,25:29,:,i))));
end

for i =1:100
regCO2(i) = sum(sum(da(33:39,25:29).*CO2_time_ano(33:39,25:29,i)));
end

meanPO4 = nanmean(regPO4);
stdPO4 = nanstd(regPO4);
std_regPO4 = (regPO4-meanPO4)/stdPO4;

meanNO3 = nanmean(regNO3);
stdNO3 = nanstd(regNO3);
std_regNO3 = (regNO3-meanNO3)/stdNO3;

meanSiO2 = nanmean(regSiO2);
stdSiO2 = nanstd(regSiO2);
std_regSiO2 = (regSiO2-meanSiO2)/stdSiO2;

meanFe = nanmean(regFe);
stdFe = nanstd(regFe);
std_regFe = (regFe-meanFe)/stdFe;

meandiatom = nanmean(regdiatom);
stddiatom = nanstd(regdiatom);
std_regdiatom = (regdiatom-meandiatom)/stddiatom;

meancocco = nanmean(regcocco);
stdcocco = nanstd(regcocco);
std_regcocco = (regcocco-meancocco)/stdcocco;

meanNPP = nanmean(regNPP);
stdNPP = nanstd(regNPP);
std_regNPP = (regNPP-meanNPP)/stdNPP;

meanCO2 = nanmean(regCO2);
stdCO2 = nanstd(regCO2);
std_regCO2 = (regCO2-meanCO2)/stdCO2;

year =1:100;
plot(year,std_regdiatom,'r-','linewidth',2);
hold on;
plot(year,std_regcocco,'b-','linewidth',2);
plot(year,std_regNPP,'g-','linewidth',2);
plot(year,std_regCO2,'k-','linewidth',2);
xlabel('Time from pertubation','fontsize',16);
legend('Diatoms','Coccolithophores','NPP','air-sea CO2 flux');
ax=get(gcf,'currentaxes');
set(ax,'fontsize',16);

print -dpdf -r600 BB_timeseries.pdf




