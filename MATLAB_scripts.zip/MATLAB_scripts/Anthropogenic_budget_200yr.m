%% Calculate change in the global budget
close all;clear all;clc;
addpath m_map
load anhcolor
%% load grid formation
x = rdmds('XC');
y = rdmds('YC');
z = rdmds('RC');
dx = rdmds('DXG');
dy = rdmds('DYG');
dz = rdmds('DRF');
da = rdmds('RAC');
hc = rdmds('hFacC');
dz3d = repmat(dz,[128 64 1]).*hc;
dv = repmat(da,[1 1 23]).*repmat(dz,[128 64 1]).*hc;
%% wrap around the globe
x(end+1,:)= x(end,:)+1;
y(end+1,:)= y(1,:);
%% load PI_results
% tracers
tracers_PI = rdmds('PI/PTRD1', 5040000);
mask = ones(128, 64);
mask(tracers_PI(:,:,1,1)==0)=NaN;
PO4_PI = tracers_PI(:,:,:,1);
NO3_PI = tracers_PI(:,:,:,2);
Fe_PI = tracers_PI(:,:,:,3);
SiO2_PI = tracers_PI(:,:,:,4);
% Phytoplankton
tracers2_PI = rdmds('PI/PTRD3',5040000);
Phy01_PI = tracers2_PI(:,:,:,2);
Phy02_PI = tracers2_PI(:,:,:,3);
Phy03_PI = tracers2_PI(:,:,:,4);
Phy04_PI = tracers2_PI(:,:,:,5);
Phy05_PI = tracers2_PI(:,:,:,6);
Phy06_PI = tracers2_PI(:,:,:,7);

Phy01_PI2d = sum(Phy01_PI.*dz3d,3);
Phy05_PI2d = sum(Phy05_PI.*dz3d,3);
Phy06_PI2d = sum(Phy06_PI.*dz3d,3);
Phy03_PI2d = sum(Phy03_PI.*dz3d,3);
Phy04_PI2d = sum(Phy04_PI.*dz3d,3);
% Production
Prod_PI = rdmds('PI/Production',5040000);
PP_PI2d = sum(Prod_PI.*dz3d,3);

% CO2flux
CO2_PI = rdmds('PI/CO2flux',5040000);

%% load Industrial Results 100 years
% tracers
tracers_100_yr = rdmds('100yr/PTRD1', 5112000);
mask = ones(128, 64);
mask(tracers_100_yr(:,:,1,1)==0)=NaN;
PO4_100_yr = tracers_100_yr(:,:,:,1);
NO3_100_yr = tracers_100_yr(:,:,:,2);
Fe_100_yr = tracers_100_yr(:,:,:,3);
SiO2_100_yr = tracers_100_yr(:,:,:,4);

PO4_100_yr_ano = PO4_100_yr - PO4_PI;
NO3_100_yr_ano  = NO3_100_yr - NO3_PI;
Fe_100_yr_ano = Fe_100_yr - Fe_PI;
SiO2_100_yr_ano = SiO2_100_yr - SiO2_PI;
% Phytoplankton
tracers2_100_yr = rdmds('100yr/PTRD3',5112000);
Phy01_100_yr = tracers2_100_yr(:,:,:,2);
Phy02_100_yr = tracers2_100_yr(:,:,:,3);
Phy03_100_yr = tracers2_100_yr(:,:,:,4);
Phy04_100_yr = tracers2_100_yr(:,:,:,5);
Phy05_100_yr = tracers2_100_yr(:,:,:,6);
Phy06_100_yr = tracers2_100_yr(:,:,:,7);

Phy01_100_yr2d = sum(Phy01_100_yr.*dz3d,3);
Phy05_100_yr2d = sum(Phy05_100_yr.*dz3d,3);
Phy06_100_yr2d = sum(Phy06_100_yr.*dz3d,3);
Phy03_100_yr2d = sum(Phy03_100_yr.*dz3d,3);
Phy04_100_yr2d = sum(Phy04_100_yr.*dz3d,3);

Phy01_100_yr_ano = Phy01_100_yr - Phy01_PI;
Phy02_100_yr_ano = Phy02_100_yr - Phy02_PI;
Phy03_100_yr_ano = Phy03_100_yr - Phy03_PI;
Phy04_100_yr_ano = Phy04_100_yr - Phy04_PI;
Phy05_100_yr_ano = Phy05_100_yr - Phy05_PI;
Phy06_100_yr_ano = Phy06_100_yr - Phy06_PI;

Phy01_100_yr_ano_2d = sum(Phy01_100_yr_ano.*dz3d,3);
Phy02_100_yr_ano_2d = sum(Phy02_100_yr_ano.*dz3d,3);
Phy03_100_yr_ano_2d = sum(Phy03_100_yr_ano.*dz3d,3);
Phy04_100_yr_ano_2d = sum(Phy04_100_yr_ano.*dz3d,3);
Phy05_100_yr_ano_2d = sum(Phy05_100_yr_ano.*dz3d,3);
Phy06_100_yr_ano_2d = sum(Phy06_100_yr_ano.*dz3d,3);
% Production
Prod_100_yr = rdmds('100yr/Production',5112000);
PP_100_yr2d = sum(Prod_100_yr.*dz3d,3);
Prod_100_yr_ano = Prod_100_yr - Prod_PI;
Prod_100_yr_ano_2d = sum(Prod_100_yr_ano.*dz3d,3);
% CO2flux
CO2_100_yr = rdmds('100yr/CO2flux',5112000);
CO2_100_yr_ano = CO2_100_yr - CO2_PI;


% Fe_50_yr_ano_surface = nanmean(Fe_50_yr_ano(:,:,1:10),3);



%% make figure, global map focusing on the Indian basin
% tracers = rdmds('PTR',Inf,'rec',3)*1e3;
conv1 = 60*60*24*365*0.001*12;
conv2 = 106;
figure(5);
% c = nanmean(SiO2_200_yr_ano(:,:,1:10),3);
% c = PIC_In(:,:,1);
c = (Phy03_100_yr_ano_2d+Phy04_100_yr_ano_2d)*conv2;
c = Phy02_100_yr_ano_2d*conv2;
c = CO2_100_yr_ano*conv1
c(end+1,:)=c(1,:);

m_proj('miller','lat',[-70 30],'lon',[30 120]);
m_pcolor(x(11:43,4:43),y(11:43,4:43),c(11:43,4:43));
shading flat;
m_coast('patch',[.5 .5 .5]);
m_grid('xaxis','bottom','box','fancy');
% lon = x(20:25,20:28);
% lat = y(20:25,20:28);
% m_line(lon,lat,'linewi',3,'color','k');
% hold on;
% m_proj('lambert','long',[36 54],'lat',[-45 -40],'rectbox','on');
bndry_lon=[38 38 50 50 38];
bndry_lat=[-41 -38  -38  -41  -41];
bndry_lon1=[38 38 50 50 38];
bndry_lat1=[-48 -44  -44  -48  -48];
bndry_lon2=[95 95 108 108 95];
bndry_lat2=[-20 -17  -17  -20  -20];
m_line(bndry_lon,bndry_lat,'linewi',2,'color','k');     % Area outline ...
m_line(bndry_lon1,bndry_lat1,'linewi',2,'color','k');     % Area outline ..
m_line(bndry_lon2,bndry_lat2,'linewi',2,'color','k');     % Area outline ..
% m_hatch(bndry_lon,bndry_lat,'single',30,5,'color','k'); % ...with hatching added.
caxis([-11 11]);
% colorbar;
% drawnow;

%% make colorbar at the bottom
% cmp=colormap('jet');
cmp=colormap(anhcolor);
% cmp(30:33,:) = ones(4,3);
% colormap = cmp;
colorbartype([.1 .05 .8 .025],-1:.04:1,61,[-1 1],cmp,0);
ax=get(gcf,'currentaxes');
set(ax,'xtick',1:10:61);
set(ax,'xticklabel',{'-1' '-0.6' '-0.2' '0.2' '0.6' '1'},'FontName','Times New Roman','FontSize',20);
set(ax,'fontsize',20);
title(' Vertically integrated large phyto. change, mmolC/m2','FontName', 'Times New Roman','FontName','Times New Roman', 'fontsize',20);
% title(' Air-sea CO2 flux [gC/m2/year]','FontName', 'Times New Roman','FontName','Times New Roman', 'fontsize',20); 
% title('Model PIC concentration at the surface [mmolC/m3]','FontName', 'Times New Roman','FontName','Times New Roman', 'fontsize',20);
% print -dpdf  Fe_control.pdf
print -dpdf -r600 100yr_CO2_Indian_box.pdf




